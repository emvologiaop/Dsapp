import TelegramBot from 'node-telegram-bot-api';
import dotenv from 'dotenv';

dotenv.config();

const token = process.env.TELEGRAM_BOT_TOKEN;

export function initBot() {
  if (!token) {
    console.warn("TELEGRAM_BOT_TOKEN not found. Bot will not start.");
    return null;
  }

  const bot = new TelegramBot(token, { polling: true });

  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, "Welcome to DDU Social Bot! 🚀\n\nPlease send me the 6-digit verification code from the web app to link your account.");
  });

  bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    if (text && /^\d{6}$/.test(text)) {
      try {
        // Find user with this auth code
        const db = (await import('../src/db.ts')).default;
        const user = db.prepare('SELECT * FROM users WHERE telegramAuthCode = ?').get(text) as any;
        
        if (user) {
          db.prepare('UPDATE users SET telegramChatId = ?, telegramAuthCode = NULL WHERE id = ?').run(chatId.toString(), user.id);
          bot.sendMessage(chatId, `✅ Account linked successfully, ${user.name}! You will now receive DDU Social notifications here.`);
        } else {
          bot.sendMessage(chatId, "❌ Invalid verification code. Please check the web app and try again.");
        }
      } catch (error) {
        console.error("Bot verification error:", error);
        bot.sendMessage(chatId, "⚠️ An error occurred while linking your account. Please try again later.");
      }
    } else if (text?.toLowerCase().includes('reset password')) {
      bot.sendMessage(chatId, "🔐 Password Reset Requested.\n\nPlease provide your registered email address to receive an OTP.");
    } else if (text?.toLowerCase().includes('@')) {
      // Simulate OTP generation
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      bot.sendMessage(chatId, `🔑 Your DDU Social Password Reset OTP is: ${otp}\n\nUse this code in the web app to reset your password.`);
    } else if (text?.toLowerCase().includes('support')) {
      bot.sendMessage(chatId, "Contact @Dev_Envologia for technical issues.");
    }
  });

  console.log("Telegram Bot initialized");
  return bot;
}
